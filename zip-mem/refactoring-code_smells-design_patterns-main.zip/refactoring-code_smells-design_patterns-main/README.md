<p align="center">
  <a href="https://codely.com">
    <img src="https://user-images.githubusercontent.com/10558907/170513882-a09eee57-7765-4ca4-b2dd-3c2e061fdad0.png" width="300px" height="92px"/>
  </a>
</p>

<h1 align="center">
  Refactoring from Code Smells to Clean Code
  <br />
  🧼💩 🔜 🌈🦄
</h1>

<p align="center">
    <a href="https://github.com/CodelyTV"><img src="https://img.shields.io/badge/CodelyTV-OS-green.svg?style=flat-square" alt="CodelyTV Open Source"/></a>
    <a href="http://codely.tv/pro/cursos"><img src="https://img.shields.io/badge/CodelyTV-PRO-black.svg?style=flat-square" alt="CodelyTV Pro Courses"/></a>
</p>

<p align="center">
  Showcase of the refactorings and code smells catalog illustrated with practical examples in different programming languages.
  <br />
  <br />
  <a href="https://pro.codely.tv/library/refactoring-code-smells-clean-code-bloaters/">🎥 View refactoring course</a>
  ·
  <a href="https://github.com/CodelyTV/refactoring-code-smells/stargazers">⭐ Star this repository</a>
  ·
  <a href="https://github.com/CodelyTV/refactoring-code-smells/issues">☝️ Propose an example</a>
</p>

## 🧠 Concepts 

### 💩 Code Smells

These are what we could consider as potential bad practices. Things such as long methods, nested conditionals, feature envy, and so on 😊

The different Code Smells are grouped based on the following taxonomy ([source](https://mmantyla.github.io/BadCodeSmellsTaxonomy)) where you will find each one of the single examples:

* Bloaters: Something that has grown so large that it cannot be effectively handled
* Object-Orientation Abusers: Solutions that does not fully exploit the possibilities of object-oriented design
* Change Preventers: hinder changing or further developing the software
* Dispensables: Something unnecessary that should be removed from the source code
* Couplers: Promotes coupling (knowledge particularities) between different classes

### 🧼 Refactorings

👷‍ Work in progress

### 🌈 Examples

👷‍ Work in progress

## 🤯 How to explore this repository

You have the following 3 main folders:

* 💩 Code Smells
* 🧼 Refactorings
* 🌈 Examples

The purpose of this repository is to illustrate with some _🌈 Examples_ how we can detect _💩 Code Smells_ and evolve a specific code applying _🧼 Refactorings_ technics.

That is the reason why the code will always be located in the _🌈 Examples_ folder with a folder for each of its possible evolutions, and linked from the _💩 Code Smells_ and _🧼 Refactorings_ directories using symbolic links.

## 👌 Examples completeness

The examples you will find in this repository are completely operational projects that you can open up in your IDE and start refactoring executing the provided test suite.

That is, we understand that in order to have a better learning experience, you must have the whole picture of the specific code snippet you actually want to analyze. This gives you the freedom to modify it right away after cloning this project without having to worry about _boilerplaty aspects_.

## 🤝 Contributing

Feel free to open an issue explaining how you want to contribute before starting out coding and we will help you figuring out the best way to approach it 😊
